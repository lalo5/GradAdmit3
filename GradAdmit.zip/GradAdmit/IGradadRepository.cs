﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EdGradAssist
{
	//public interface IGradadRepository
	//{
	//	IQueryable<Gradad_db> ReadAllGradad;
	//}
}
