﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EdGradAssist.Models.Entities;

namespace EdGradAssist.ViewModel
{
	public class Student
	{
		public Student Students { get; set; }

		public Application Applications { get; set; }
	}
}
